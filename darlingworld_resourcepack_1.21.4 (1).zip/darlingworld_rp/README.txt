DarlingWorld resource pack for Minecraft 1.21.4

What it does:
- Replaces the symbol "-" with the DarlingWorld image.
- Also maps the private-use character U+E000 to the same image.

Important:
- Because "-" is overridden, every hyphen/minus shown with this pack will become the image.
- If you want a safer option, use the private character U+E000 instead of "-" in your scoreboard/plugin.

Suggested usage:
- Scoreboard line with hyphen: "-"
- Safer custom character: "\uE000"

Files:
- assets/minecraft/font/default.json
- assets/minecraft/textures/font/darlingworld.png
